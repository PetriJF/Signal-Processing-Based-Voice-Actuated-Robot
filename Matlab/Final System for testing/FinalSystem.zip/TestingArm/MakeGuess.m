%Time domain

% Add all the coefficients together
C1 = C1a + C1b + C1c + C1d + C1e + C1f;
[M,I1] = max(C1);
guess1 = I1;
