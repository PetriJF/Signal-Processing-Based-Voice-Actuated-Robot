ReferenceSignalTimeFormat1=[audioread("leftRef1.wav"),audioread("rightRef1.wav")];
ReferenceSignalTimeFormat2=[audioread("leftRef2.wav"),audioread("rightRef2.wav")];
ReferenceSignalTimeFormat3=[audioread("leftRef3.wav"),audioread("rightRef3.wav")];
ReferenceSignalTimeFormat4=[audioread("leftRef4.wav"),audioread("rightRef4.wav")];
ReferenceSignalTimeFormat5=[audioread("leftRef5.wav"),audioread("rightRef5.wav")];
ReferenceSignalTimeFormat6=[audioread("leftRef6.wav"),audioread("rightRef6.wav")];

ReferenceSignalFourierTransform1=[audioread("leftRef1.wav"),audioread("rightRef1.wav")];
ReferenceSignalFourierTransform2=[audioread("leftRef2.wav"),audioread("rightRef2.wav")];
ReferenceSignalFourierTransform3=[audioread("leftRef3.wav"),audioread("rightRef3.wav")];
ReferenceSignalFourierTransform4=[audioread("leftRef4.wav"),audioread("rightRef4.wav")];
ReferenceSignalFourierTransform5=[audioread("leftRef5.wav"),audioread("rightRef5.wav")];
ReferenceSignalFourierTransform6=[audioread("leftRef6.wav"),audioread("rightRef6.wav")];


SingularReferenceFormat = [audioread("leftRef1.wav"), audioread("leftRef2.wav"), audioread("leftRef3.wav"), audioread("leftRef4.wav"), audioread("leftRef5.wav"), audioread("leftRef6.wav"), audioread("rightRef1.wav"), audioread("rightRef2.wav"), audioread("rightRef3.wav"), audioread("rightRef4.wav"), audioread("rightRef5.wav"), audioread("rightRef6.wav")];